<template>
  <div>
    <h2>Knowledge Base</h2>
    <p>这里是知识库问答独立页面</p>
  </div>
</template>
