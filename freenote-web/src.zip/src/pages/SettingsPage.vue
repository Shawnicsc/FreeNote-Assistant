<template>
  <div>
    <h2>Settings</h2>
    <p>这里是 AI 源配置页面</p>
  </div>
</template>
